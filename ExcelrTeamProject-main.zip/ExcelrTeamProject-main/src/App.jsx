import React from 'react'
import './App.css'
import './App.scss'
import Home from './Home'

function App() {
 

  return (
   
      <div><Home/></div>
   
  )
}

export default App
