import React from 'react';
import Calendar from '../Calender/calendar';
const Addtask = () => {
    return (
        <div>

                        <React.StrictMode>
                            <Calendar/>
                        </React.StrictMode>
        </div>
    );
};
export default Addtask