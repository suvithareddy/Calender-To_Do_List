import React from 'react';
import './Dasboard.css'
import Sidebar from './Sidebar'
import Content from './content';
const Dashboard = () => {
    return (
           
        
        <div>
            <nav>
                <h1>Dashboard</h1>
                </nav>
            <div class="container-row">
                
              
                <Sidebar />
                
                
                
            </div>


        </div>










    );
};

export default Dashboard;