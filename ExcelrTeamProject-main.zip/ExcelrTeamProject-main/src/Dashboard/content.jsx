


function Content(){
return(
    <div>
       <div className='main-cards '>
        <div className='card'style={{ width: 300, height: 150,  backgroundColor: 'orange',margin:100,padding:50}}>
                <div className='card-body'>
                    <h3>PENDING TASKS</h3>
                    
                </div>
            </div>
        </div>
        </div>
)
}
export default Content