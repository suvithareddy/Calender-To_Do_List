// import React from 'react';
// import Calendar from './calendar';

// function App() {
//   return (
//     <div className="app">
//       <Calendar />
//     </div>
//   );
// }

// export default App;







// import Dashboard from '../pages/Dashboard';
// function Calendar() {
//   const [pendingTasks, setPendingTasks] = useState([]);

//   useEffect(() => {
//     const today = new Date().toISOString().split('T')[0];
//     const filteredTasks = tasks.filter((task) => task.date >= today);
//     setPendingTasks(filteredTasks);
//   }, [tasks]); 
// }



// <h2>Upcoming Tasks</h2>
//       <Dashboard pendingTasks={pendingTasks} />
     